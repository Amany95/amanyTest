//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Caner Ça on 22.11.2018.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
