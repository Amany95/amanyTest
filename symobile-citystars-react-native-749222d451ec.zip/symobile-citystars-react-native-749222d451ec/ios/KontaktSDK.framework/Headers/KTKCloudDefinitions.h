//
//  KontaktSDK
//  Version: 1.5.1
//
//  Copyright © 2017 Kontakt.io. All rights reserved.
//

typedef NS_ENUM(NSInteger, KTKProximity) {
    KTKProximityUnknown,
    KTKProximityImmediate,
    KTKProximityNear,
    KTKProximityFar
};
