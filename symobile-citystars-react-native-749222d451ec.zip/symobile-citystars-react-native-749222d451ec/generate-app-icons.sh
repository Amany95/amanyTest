#!/usr/bin/env bash
yo rn-toolbox:assets --icon ./icon.png