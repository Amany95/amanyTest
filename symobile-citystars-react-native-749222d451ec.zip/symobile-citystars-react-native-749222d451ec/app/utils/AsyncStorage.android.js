import FilesystemStorage from "redux-persist-filesystem-storage";

export default FilesystemStorage;
