export const THE_SIDEBAR_DEFAULT = 'default';
export const THE_SIDEBAR_FACEBOOK = 'facebook';
export const THE_SIDEBAR_AMAZING = 'amazing';
